//
//  SPCameraScreenV2ViewController.swift
//  SpyneFrameworkDebug
//
//  Created by Akash Verma on 27/11/22.
//

import UIKit
import AVFoundation
import Realm
import CoreMotion
import RealmSwift

//MARK: - Class - SPCameraScreenV2ViewController
/// Main class developed for the New camera Experience
class SPCameraScreenV2ViewController: UIViewController {
    
    //MARK: - IBOutlets
    @IBOutlet var overlayInfoView: UIView!
    @IBOutlet var cameraForegroundView: UIView!
    @IBOutlet weak var overlayNameLabel: UILabel!
    @IBOutlet weak var imgCapturedImage: UIImageView!
    @IBOutlet weak var overlaySideImage: UIImageView!
    @IBOutlet weak var captureButton: UIButton!
    @IBOutlet weak var cameraView: UIView!
    @IBOutlet weak var skuNameLabel: UILabel!
    
    ///Shoot type configuration View
    @IBOutlet weak var exteriorView: UIView!
    @IBOutlet weak var interiorView: UIView!
    @IBOutlet weak var miscButtonView: UIView!
    @IBOutlet weak var exteriorImage: UIImageView!
    @IBOutlet weak var exteriorLeadingImage: UIImageView!
    @IBOutlet weak var interiorImage: UIImageView!
    @IBOutlet weak var interiorLeading: UIImageView!
    @IBOutlet weak var miscImage: UIImageView!

    ///Gyrometer configuration
    @IBOutlet weak var viewGyrometer: UIView!
    @IBOutlet weak var imgGyroFrame: UIImageView!
    @IBOutlet weak var viewGyroline: UIView!
    @IBOutlet weak var conLineVerticleContainer: NSLayoutConstraint!
    @IBOutlet weak var gyroMeterValueLabel: UILabel!
    
    //MARK: - AV Components
    var previewLayer: AVCaptureVideoPreviewLayer!
    var captureSession: AVCaptureSession!
    var cameraDevice: AVCaptureDevice!
    var stillImageOutput: AVCapturePhotoOutput!
    var device = AVCaptureDevice.default(for: .video)
    
    //MARK: - GyroMeter
    let motionManager = CMMotionManager()
    
    //MARK: - Focus and Exosure
    var zoomGesture = UIPinchGestureRecognizer()
    var focusGesture = UITapGestureRecognizer()
    var exposureGesture = UIPanGestureRecognizer()
    var lastFocusRectangle: CAShapeLayer?
    var lastFocusPoint: CGPoint?
    var exposureValue: Float = 0.1 // EV
    var translationY: Float = 0
    var startPanPointInPreviewLayer: CGPoint?
    let exposureDurationPower: Float = 4.0 // the exposure slider gain
    let exposureMininumDuration: Float64 = 1.0 / 2000.0
    var zoomScale = CGFloat(1.0)
    var beginZoomScale = CGFloat(1.0)
    var maxZoomScale = CGFloat(1.0)
    /// Property to set focus mode when tap to focus is used (_focusStart).
    open var focusMode: AVCaptureDevice.FocusMode = .continuousAutoFocus
    /// Property to set exposure mode when tap to focus is used (_focusStart).
    open var exposureMode: AVCaptureDevice.ExposureMode = .continuousAutoExposure
    
    //MARK: - Realm
    let localRealm = try? Realm()

    
    //MARK: - Variables
    var shootType = ShootType.Exterior
    var shootStatus = SPStudioShootStatusModel(onExterior: true, exteriorDone: false, onInterior: false, interiorDone: false, onMisc: false, miscDone: false)
    var exteriorOverlays = getExteriorOverlayData()
    var interiorOverlays = getInteriorOverlayData()
    var miscOverlays = getMisclenousOverlayData()
    var drawerUpdateCellDelegate: SPOverlayDrawerContentUpdateDelegate?
    
    //MARK: - To be refractored
    // Variable
    var is360Interior = false
    var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    var vmShoot = SPShootViewModel()
    let sequence = MaterialShowcaseSequence()
    var isFirstCLick = false
    var isShowcaseDone = false
    var realmProjectObject = RealmProjectData()
    var vmRealm = RealmViewModel()
    var isReclick = false
    
    //MARK: - ViewController Life cycle methods
    ///ViewDidLoad: All kind of initialization which is needed to start on the view

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configuringViewModel()
        setUpUI()
        AppUtility.lockOrientation(.landscapeRight, andRotateTo: .landscapeRight)
        getMotion()
        setUpGestureRecognizers()
        setupCameraFunctionality()
        configureShootStatusView()
    }
    
    //MARK: - Class Methods
    ///setUpUI: All type of UI Colmponenets configuration to be done here
    func setUpUI() {
        self.navigationItem.setHidesBackButton(true, animated: true)
        configureOverlayAndOverlayName(overlayModel: exteriorOverlays.first)
    }
    
    func configureOverlayAndOverlayName(overlayModel: OverlayData?) {
        guard let overlayModel else { return }
        self.overlaySideImage.sd_setImage(with: URL(string: overlayModel.displayThumbnail ?? ""))
        self.overlayNameLabel.text = overlayModel.displayName ?? ""
        self.imgCapturedImage.sd_setImage(with: URL(string: overlayModel.displayThumbnail ?? ""))
    }
    
    func configuringViewModel() {
        self.vmShoot.selectedIndex = 0
        self.vmShoot.projectName = SpyneSDK.shared.skuId
        self.vmShoot.cat_id = SpyneSDK.shared.categoryID
        self.vmShoot.sub_cat_id = SPStudioSetupModel.subCategoryID ?? ""
        self.vmShoot.arrOverLays = getExteriorOverlayData()
        self.vmShoot.noOfAngles = getExteriorOverlayData().count
        oldCodeConfiguration()
    }
    
    func oldCodeConfiguration() {
        if DraftStorage.isFromDraft{
            if vmShoot.skuId != ""{
                self.isFirstCLick = true
            } else {
                self.isFirstCLick = false
            }
        }
    }
    
    ///setUpGestureRecognizers: All type of gesture recognizers enabling
    func setUpGestureRecognizers() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.openOverlayDrawer(_:)))
        overlayInfoView.addGestureRecognizer(tap)
        let exteriorTap = UITapGestureRecognizer(target: self, action: #selector(self.setToExteriorShootType(_:)))
        exteriorView.addGestureRecognizer(exteriorTap)
        let interiorTap = UITapGestureRecognizer(target: self, action: #selector(self.setToInteriorShootType(_:)))
        interiorView.addGestureRecognizer(interiorTap)
        let miscTap = UITapGestureRecognizer(target: self, action: #selector(self.setToMiscShootType(_:)))
        miscButtonView.addGestureRecognizer(miscTap)
    }
    
    ///setupCameraFunctionality: It setup the camera - Camera Implemetation has dedicated file : SPCameraScreenV2ViewController+CameraSetup
    func setupCameraFunctionality() {
        attachZoom(cameraView)
        attachFocus(cameraView)
        attachExposure(cameraView)
        self.cameraSetup()
    }
    
    func configureShootStatusView(){
        if self.shootStatus.onExterior {
            self.exteriorImage.image = UIImage(named: "lineCircle")
            self.exteriorLeadingImage.image = UIImage(named: "dottedLine")
        } else {
            self.exteriorImage.image = UIImage(named: "dottedCircle")
            self.exteriorLeadingImage.image = UIImage(named: "dottedLine")
        }
        if self.shootStatus.exteriorDone {
            self.exteriorImage.image = UIImage(named: "greenCircle")
            self.exteriorLeadingImage.image = UIImage(named: "greenLine")
        }
        if self.shootStatus.onInterior {
            self.interiorImage.image = UIImage(named: "lineCircle")
            self.interiorLeading.image = UIImage(named: "dottedLine")
        } else {
            self.interiorImage.image = UIImage(named: "dottedCircle")
            self.interiorLeading.image = UIImage(named: "dottedLine")
        }
        if self.shootStatus.interiorDone {
            self.interiorImage.image = UIImage(named: "greenCircle")
            self.interiorLeading.image = UIImage(named: "greenLine")
        }
        if self.shootStatus.onMisc {
            self.miscImage.image = UIImage(named: "lineCircle")
        } else {
            self.miscImage.image = UIImage(named: "dottedCircle")
        }
        if self.shootStatus.miscDone {
            self.miscImage.image = UIImage(named: "greenCircle")
        }
    }
    
    ///openOverlayDrawer: Is a method which basically adds the custom view to the Viewcontroller
    ///openOverlayDrawer: This view basically shows the clicked Image and upcoming overlays
    @objc func openOverlayDrawer(_ sender: UITapGestureRecognizer? = nil) {
        var containsDrawerView = true
        for item in cameraForegroundView.subviews {
            if item.tag == 10010 {
                item.fadeOut() {_ in
                    item.removeFromSuperview()
                    self.cameraForegroundView.isUserInteractionEnabled = false
                }
                captureButton.isEnabled = true
                containsDrawerView = false
            }
        }
        if containsDrawerView {
            let customView = SPOverlaysDrawer(frame: CGRect(x: 0, y: 0, width: 380, height: 376))
            self.drawerUpdateCellDelegate = customView
            customView.tag = 10010
            customView.selectedCellDelegate = self
            customView.vmShoot = vmShoot
            customView.commonInit()
            cameraForegroundView.isUserInteractionEnabled = true
            customView.shootType = shootType
            self.cameraForegroundView.addSubview(customView)
            customView.contentView.fadeIn()
            captureButton.isEnabled = false
        }
    }
    
    @objc func setToExteriorShootType(_ sender: UITapGestureRecognizer? = nil) {
        shootType = .Exterior
        shootStatus.onExterior = true
        shootStatus.onMisc = false
        shootStatus.onInterior = false
        drawerUpdateCellDelegate?.updateDrawerOverlayCells(shootType: .Exterior)
        configureShootStatusView()
    }
    
    @objc func setToInteriorShootType(_ sender: UITapGestureRecognizer? = nil) {
        shootType = .Interior
        shootStatus.onExterior = false
        shootStatus.onMisc = false
        shootStatus.onInterior = true
        drawerUpdateCellDelegate?.updateDrawerOverlayCells(shootType: .Interior)
        configureShootStatusView()
    }
    
    @objc func setToMiscShootType(_ sender: UITapGestureRecognizer? = nil) {
        shootType = .Misc
        shootStatus.onExterior = false
        shootStatus.onMisc = true
        shootStatus.onInterior = false
        drawerUpdateCellDelegate?.updateDrawerOverlayCells(shootType: .Misc)
        configureShootStatusView()
    }
    
    func getMotion() {
        if motionManager.isGyroAvailable {
            motionManager.deviceMotionUpdateInterval = 0.1
            motionManager.startDeviceMotionUpdates(to: OperationQueue()) { [weak self] (motion, error) -> Void in
                
                if let attitude = motion?.attitude {
                    let roll = (attitude.roll * 180 / Double.pi) + 90
                    DispatchQueue.main.async{
                        self?.conLineVerticleContainer.constant = CGFloat(roll)
                        self?.gyroMeterValueLabel.text = "\(String(describing: Int(self?.conLineVerticleContainer.constant ?? 0)))" + "°"
                        guard let gravity = motion?.gravity else{
                            return
                        }
                        let rotation = atan2(gravity.y, gravity.x) - Double.pi
                        //Change the view's transform from the main thread.
                        self?.viewGyroline.transform = CGAffineTransform(rotationAngle: CGFloat(-1*rotation))
                        let degrees = (rotation * 180 / .pi)+360
                        if (roll > -10 && roll < 10) && (degrees < 10 || degrees > 350){
                            self?.imgGyroFrame.tintColor = UIColor.green
                            self?.viewGyroline.backgroundColor = UIColor.green
                            self?.captureButton.isUserInteractionEnabled = true
                            self?.captureButton.tintColor = UIColor.white
                            self?.view.hideAllToasts()
                        }
                        else{
                            self?.showToast(message: Alert.redGyrometerError)
                            self?.imgGyroFrame.tintColor = UIColor.red
                            self?.viewGyroline.backgroundColor = UIColor.red
                            self?.captureButton.isUserInteractionEnabled = false
                            self?.captureButton.tintColor = UIColor.lightGray
                        }
                    }
                }
            }
            print("Device motion started")
        }else{
            ShowAlert(message: Alert.gyroScopeNotAvailable, theme: .warning)
        }
        
    }
    
    func checkCameraAccess() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .denied:
            print("Denied, request permission from settings")
            presentCameraSettings()
        case .restricted:
            print("Restricted, device owner must approve")
            presentCameraSettings()
        case .authorized:
            print("Authorized, proceed")
            startCamera()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { success in
                if success {
                    print("Permission granted, proceed")
                    self.startCamera()
                } else {
                    print("Permission denied")
                    self.presentCameraSettings()
                }
            }
        @unknown default:
            presentCameraSettings()
        }
    }
    
    func presentCameraSettings() {
        let alertController = UIAlertController(title: "IMPORTANT",
                                      message: "Camera access required for capturing photos!",
                                      preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Cancel", style: .default))
        alertController.addAction(UIAlertAction(title: "Settings", style: .cancel) { _ in
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url, options: [:], completionHandler: { _ in
                    // Handle
                })
            }
        })
        present(alertController, animated: true)
    }
    
    
    func startCamera(){
        #if targetEnvironment(simulator)
        ShowAlert(message: "Simulator not supported camera", theme: .warning)
        #else
        let settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
        stillImageOutput.capturePhoto(with: settings, delegate: self)
        #endif
    }
    
    //MARK: - IBActions
    ///flashLightButtonTouchUpInside: Toggles the torch status
    @IBAction func flashLightButtonTouchUpInside(_ sender: Any) {
        if let device = AVCaptureDevice.default(for: AVMediaType.video), device.hasTorch {
            do {
                try device.lockForConfiguration()
                if device.torchMode == .on {
                    device.torchMode = .off
                } else {
                    device.torchMode = .on
                }
                device.unlockForConfiguration()
            }
            catch {
                print(SPStringV2.torchError)
            }
        }
    }
    
    @IBAction func captureImageButton(_ sender: Any) {
        checkCameraAccess()
    }
    
}

extension SPCameraScreenV2ViewController: SPSelectedCellDelegate {
    func updateSelectedCell(index: Int, shootType: ShootType) {
        vmShoot.selectedIndex = index
        imgCapturedImage.sd_setImage(with: URL(string: vmShoot.arrOverLays[index].displayThumbnail ?? ""))
        overlaySideImage.sd_setImage(with: URL(string: vmShoot.arrOverLays[index].displayThumbnail ?? ""))
        openOverlayDrawer()
    }
}
