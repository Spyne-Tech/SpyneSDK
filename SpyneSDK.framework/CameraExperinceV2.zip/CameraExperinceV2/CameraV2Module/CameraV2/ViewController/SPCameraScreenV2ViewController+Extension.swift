//
//  SPCameraScreenV2ViewController+Extension.swift
//  SpyneFrameworkDebug
//
//  Created by Akash Verma on 05/12/22.
//

import UIKit

extension SPCameraScreenV2ViewController {
    
    func createProjectandSku(){
        let projectdta = [
            "project_name": SpyneSDK.shared.skuId,
            "category_id": SpyneSDK.shared.categoryID,
            "source" : "App_ios",
            "superuser_id" : USER.dealerShipId
        ]as [String:Any]
        let skudta = [[
            "sku_name": SpyneSDK.shared.skuId,
            "prod_cat_id": SpyneSDK.shared.categoryID,
            "prod_sub_cat_id" : SPStudioSetupModel.subCategoryID ?? "",
            "total_frames_no" : "\(vmShoot.arrOverLays.count)",
            "initial_no" : 0,
            "image_present" : 1,
            "video_present" : 0,
            "source" : "App_ios"
        ]]as [[String:Any]]
        let projectData = try! JSONSerialization.data(withJSONObject: projectdta)
        let projectString = NSString(data: projectData, encoding: String.Encoding.utf8.rawValue)
        let skuData = try! JSONSerialization.data(withJSONObject: skudta)
        let skuString = NSString(data: skuData, encoding: String.Encoding.utf8.rawValue)
        print(projectString!)
        print(skuString!)
        vmShoot.createProjectandSku(projectdta: projectdta, skudta: skudta) {skudetail in
            self.vmShoot.projectId = skudetail.data.projectID
            self.vmShoot.skuId = skudetail.data.skusList[0].skuID
            // Save data in Realm
            self.realmProjectObject = RealmProjectData(authKey: CLIENT.shared.getUserSecretKey(), prodCatId: self.vmShoot.cat_id, subCatId: self.vmShoot.sub_cat_id, projectId: self.vmShoot.projectId, projectName: self.vmShoot.projectName, skuId: self.vmShoot.skuId, imageCategory: StringCons.exterior, completedAngles: 0, noOfAngles: self.vmShoot.noOfAngles, noOfInteriorAngles: Storage.shared.arrInteriorPopup.count , noOfMisAngles: Storage.shared.arrFocusedPopup.count , interiorSkiped: false, misSkiped: false, is360IntSkiped: false)
            
            try? RealmViewModel.main.realm.safeWrite {
                RealmViewModel.main.realm.add(self.realmProjectObject)
            }
            if  !DraftStorage.isEmptySku{
                
                let realmSkuObject = RealmSkuData(projectId: self.vmShoot.projectId, skuId: self.vmShoot.skuId, skuName: self.vmShoot.skuName, completedAngles: 0)
                
                try? RealmViewModel.main.realm.safeWrite {
                    RealmViewModel.main.realm.add(realmSkuObject)
                    self.setImageUploadData()
                }
                
            }else{
                let taskToUpdate =
                self.vmRealm.getRealmData(projectId: DraftStorage.draftProjectId)
                
                try! self.localRealm?.safeWrite {
                    taskToUpdate?.authKey = USER.authKey
                    taskToUpdate?.prodCatId = self.vmShoot.cat_id
                    taskToUpdate?.subCatId = self.vmShoot.sub_cat_id
                    taskToUpdate?.projectId = self.vmShoot.projectId
                    taskToUpdate?.projectName = self.vmShoot.projectName
                    taskToUpdate?.skuId = self.vmShoot.skuId
                    taskToUpdate?.imageCategory = "Exterior"
                    taskToUpdate?.completedAngles = 0
                    taskToUpdate?.noOfAngles = self.vmShoot.noOfAngles
                    taskToUpdate?.interiorSkiped = false
                    taskToUpdate?.misSkiped = false
                    taskToUpdate?.is360IntSkiped = false
                    self.setImageUploadData()
                }
            }
        } onError: { message in
            ShowAlert(message: message, theme: .warning)
        }
    }
    
    func setImageUploadData(){
        self.uploadImage(capturedImage: self.vmShoot.capturedImage)
    }
    
    func uploadImage(capturedImage:UIImage){
    
        //get selected overlay Id
        let overlayId =  "\(vmShoot.arrOverLays[vmShoot.selectedAngle].id ?? 0)"
        let clickedAngleCount = vmShoot.arrOverLays.filter{$0.clickedAngle}.count
        
        if vmShoot.arrOverLays[vmShoot.selectedAngle].frameSeqNo == 0{
            vmShoot.arrOverLays[vmShoot.selectedAngle].frameSeqNo = (clickedAngleCount ) + 1
        }
        
        let imageObject = RealmImageData(userId: USER.userId)
        
        imageObject.projectId = vmShoot.projectId
        imageObject.skuId = vmShoot.skuId
        imageObject.skuName = vmShoot.skuName
        imageObject.imageCategory = StringCons.exterior
        imageObject.overlay_id = overlayId
        imageObject.frame_seq_no = "\(vmShoot.arrOverLays[vmShoot.selectedAngle].frameSeqNo)"
        imageObject.is_reshoot = false
        imageObject.is_reclick = isReclick
        imageObject.angle = 90

        SpyneSDK.upload.saveImageToDecumentFolderAndSaveTheReferenceToRealmFile(imageObject: imageObject, image: capturedImage, selectedAngle: self.vmShoot.selectedAngle, serviceStartedBy: StringCons.exteriorImageClick)
        vmShoot.arrOverLays[vmShoot.selectedAngle].clickedAngle = true
        vmShoot.arrOverLays[vmShoot.selectedAngle].clickedImage = capturedImage
        setToNextOverlay()
    }
    
    internal func setToNextOverlay(){
        isReclick = false
        //Get clicked angle count
        let clickedAngleCount = vmShoot.arrOverLays.filter{$0.clickedAngle}.count
        //Update completed shoot count option
        let taskToUpdate = vmRealm.getRealmData(skuId:vmShoot.skuId)
        try! self.localRealm?.safeWrite {
            taskToUpdate?.completedAngles = vmShoot.arrOverLays[vmShoot.selectedAngle].frameSeqNo
        }
        if !DraftStorage.isFromDraft{
            self.vmShoot.selectedAngle = self.vmShoot.selectedAngle + 1
            if  self.vmShoot.selectedAngle <= vmShoot.arrOverLays.count{
                //Scroll Current Selected Angle if Skipped
                for (index,singleOverlay) in vmShoot.arrOverLays.enumerated(){
                    if !singleOverlay.clickedAngle{
                        self.vmShoot.selectedAngle = index
                        break
                    }
                }
            }else if clickedAngleCount < vmShoot.arrOverLays.count{
                for index in self.vmShoot.selectedAngle...vmShoot.arrOverLays.count{
                    if !vmShoot.arrOverLays[index].clickedAngle{
                        self.vmShoot.selectedAngle = index
                        break
                    }
                }
            }
        }else{
            if  self.vmShoot.selectedAngle <= vmShoot.arrOverLays.count-1{
                //Scroll Current Selected Angle if Skipped
                for (index,singleOverlay) in vmShoot.arrOverLays.enumerated(){
                    if !singleOverlay.clickedAngle{
                        self.vmShoot.selectedAngle = index
                        break
                    }
                }
            }else if clickedAngleCount < vmShoot.arrOverLays.count{
                
                for index in self.vmShoot.selectedAngle...vmShoot.arrOverLays.count{
                    if !vmShoot.arrOverLays[index].clickedAngle{
                        self.vmShoot.selectedAngle = index
                        break
                    }
                }
            }
        }
        
        if clickedAngleCount < vmShoot.arrOverLays.count{
            if Storage.shared.arrInteriorPopup.count == 0 || Storage.shared.arrInteriorPopup.count == 0{
                //Get Sub Categories if not avaolable
                vmShoot.getProductSubCategories(prod_id: (Storage.shared.getProductCategories()?.prodCatId) ?? "") {
                    //                    self.showInterialShootPopup()
                    
                } onError: { (errMessage) in
                    PosthogEvent.shared.posthogCapture(identity: "iOS Got Subcategories Failed", properties: ["message":errMessage])
                    ShowAlert(message: errMessage, theme: .error)
                }
            }else{
//                self.showInterialShootPopup()
            }
        }
        self.vmShoot.selectedIndex = (self.vmShoot.selectedIndex ?? 0) + 1
        self.imgCapturedImage.sd_setImage(with: URL(string: LocalOverlays.ExteriorOverlayData?[vmShoot.selectedAngle].displayThumbnail ?? ""))
        self.overlaySideImage.sd_setImage(with: URL(string: LocalOverlays.ExteriorOverlayData?[vmShoot.selectedAngle].displayThumbnail ?? ""))
    }
}
