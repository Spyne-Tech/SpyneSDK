//
//  SPCameraExperinceV2NavigationViewController.swift
//  SpyneFrameworkDebug
//
//  Created by Akash Verma on 02/12/22.
//

import UIKit

class SPCameraExperinceV2NavigationViewController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        _ = UIApplication.shared.delegate as! AppDelegate
        AppUtility.lockOrientation(.landscapeLeft, andRotateTo: .landscapeLeft)
        if SPCaptureImageNavigationVC.isReshoot{
            SPCaptureImageNavigationVC.isReshoot = false
            if let vc = storyboard?.instantiateViewController(withIdentifier: "SPCameraScreenV2ViewController")as? SPReshootCameraVC{
                self.setViewControllers([vc], animated: true)
            }
        }else{
            if let vc = storyboard?.instantiateViewController(withIdentifier: "SPCameraScreenV2ViewController")as? SPCameraScreenV2ViewController{
                self.setViewControllers([vc], animated: true)
            }
        }
    }
}
