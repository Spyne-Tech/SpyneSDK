//
//  SPConfiguratorPageCollectionViewCell.swift
//  SpyneFrameworkDebug
//
//  Created by Akash Verma on 29/11/22.
//

import UIKit

class SPConfiguratorPageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var subCatName: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var borderView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    func setValues(imageUrl: String, subCatNameString: String) {
        subCatName.text = subCatNameString
        imageView.sd_setImage(with: URL(string: imageUrl))
    }
}
