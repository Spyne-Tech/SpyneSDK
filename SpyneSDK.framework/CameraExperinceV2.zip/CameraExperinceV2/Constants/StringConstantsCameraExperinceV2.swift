//
//  StringConstantsCameraExperinceV2.swift
//  SpyneFrameworkDebug
//
//  Created by Akash Verma on 29/11/22.
//

import Foundation

class SPStringV2 {
    static let unableToAccessBackCamera = "Unable to access back camera!"
    static let imageCapturedFailed = "iOS Image Capture Failed"
    static let errorLockingconfiguration = "Error locking configuration"
    static let torchError = "Error operating the torch module"
}

class PostHogEventsKeys {
    static let message = "message"
}

class PostHogEventsValues {
    
}
