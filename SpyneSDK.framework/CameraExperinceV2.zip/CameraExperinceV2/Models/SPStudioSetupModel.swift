//
//  SPStudioSetupModel.swift
//  SpyneFrameworkDebug
//
//  Created by Akash Verma on 01/12/22.
//

import Foundation

struct SPStudioSetupModel {
    static var skuName: String?
    static var categoryId: String?
    static var backgroundId: String?
    static var numberPlateId: String?
    static var subCategoryID: String?
}

struct SPStudioShootStatusModel {
    var onExterior: Bool
    var exteriorDone: Bool
    var onInterior: Bool
    var interiorDone: Bool
    var onMisc: Bool
    var miscDone:Bool
}

enum ShootType {
    case Exterior
    case Interior
    case Misc
}

struct LocalOverlays {
    static var ExteriorOverlayData: [OverlayData]?
    static var InteriorOverlaysData: [CategoryMasterInterior]?
    static var MiscelenousOverlayData: [CategoryMasterInterior]?
}

func getExteriorOverlayData() -> [OverlayData] {
    return LocalOverlays.ExteriorOverlayData ?? []
}

func getInteriorOverlayData() -> [CategoryMasterInterior] {
    return LocalOverlays.InteriorOverlaysData ?? []
}

func getMisclenousOverlayData() -> [CategoryMasterInterior] {
    return LocalOverlays.MiscelenousOverlayData ?? []
}
